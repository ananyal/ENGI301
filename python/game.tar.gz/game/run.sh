#!/bin/bash
# ----------------------------------------------------------------
# <Same documentation / copyright as above>
# ----------------------------------------------------------------
cd /var/lib/cloud9/ENGI301/game
PYTHONPATH=/var/lib/cloud9/ENGI301/game python3 game.py
